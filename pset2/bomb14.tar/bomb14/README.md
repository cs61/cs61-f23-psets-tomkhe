CS 61 Problem Set 2
===================

This is bomb #14.

It belongs to tomkhe (tomhe@college.harvard.edu).
